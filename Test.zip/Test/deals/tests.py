from deals.helpers.deal_helper import DealHelper


# Create your tests here.

def test_end_deal():
	deal_id = 5
	response = DealHelper.end_deal(deal_id)
	assert response['success'] == False
