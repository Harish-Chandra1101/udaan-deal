from datetime import datetime
from django.db.models import Count
from deals.models import (
	Deal,
	UserDeal,
	User,
	Item
)


class DealHelper:
	@staticmethod
	def create_deal(deal_data):
		deal_obj = Deal(
			name=deal_data.get('deal_name'),
			start_time=deal_data.get('deal_start_time'),
			end_time=deal_data.get('deal_end_time'),
			max_items=deal_data.get('deal_max_items'),
			price=deal_data.get('deal_price'),
			item=Item.objects.get(pk=deal_data.get('item_id')),
			is_active=True
		)
		deal_obj.save()
		return {
			'success': True,
			'errors': [],
			'data': deal_obj.pk
		}

	@staticmethod
	def end_deal(deal_id):
		try:
			deal_obj = Deal.objects.get(pk=deal_id)
			deal_obj.is_active = False
			deal_obj.save()
			return {
				'success': True,
				'errors': [],
				'data': deal_obj.pk
			}
		except Exception as e:
			return {
				'success': False
			}

	@staticmethod
	def update_deal(deal_data):
		deal_obj = Deal.objects.get(pk=deal_data.get('deal_id'))
		if deal_data.get('deal_max_items'):
			deal_obj.max_items = deal_data['deal_max_items']
		if deal_data.get('deal_end_time'):
			deal_obj.end_time = deal_data['deal_end_time']
		deal_obj.save()
		response_dict = {
			'deal_id': deal_data.get('deal_id'),
			'deal_max_items': deal_obj.max_items,
			'deal_end_time': deal_obj.end_time
		}
		return {
			'success': True,
			'errors': [],
			'data': response_dict
		}

	@staticmethod
	def claim_deal(deal_id, user_id):
		deal_obj = Deal.objects.get(pk=deal_id)
		user_obj = User.objects.get(pk=user_id)
		deal_end_time = deal_obj.end_time
		curr_time = datetime.now()
		if curr_time > deal_end_time:
			return {
				'msg': 'Sorry the deal time is over!'
			}
		elif not deal_obj.is_active:
			return {
				'msg': 'Sorry the deal is not currently active!'
			}
		try:
			user_deal_obj = UserDeal.objects.get(
				user=user_obj,
				deal=deal_obj
			)
			return {
				'msg': 'Sorry you have already bought this deal!'
			}
		except Exception as e:
			print(user_deal_obj.pk)

			deals = UserDeal.objects.filter(
				deal=deal_obj,
			).order_by('deal').values(
				'deal__id'
			).annotate(count=Count('deal__id'))
			deal_count = deals[0]['count']
			if deal_count > deal_obj.max_items:
				return {
					'msg': 'Sorry max items are already bought in this deal'
				}
			else:
				new_user_deal_obj = UserDeal(
					user=user_obj,
					deal=deal_obj
				)
				new_user_deal_obj.save()
				return {
					'success': True,
					'data': new_user_deal_obj.pk
				}
