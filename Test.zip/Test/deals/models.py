from django.db import models


# Create your models here.

class ItemType(models.Model):
	name = models.CharField(max_length=100)


class Item(models.Model):
	name = models.CharField(max_length=100)
	type = models.ForeignKey(ItemType, on_delete=models.CASCADE)


class Deal(models.Model):
	name = models.CharField(max_length=100)
	start_time = models.DateTimeField()
	end_time = models.DateTimeField()
	max_items = models.PositiveIntegerField()
	price = models.FloatField()
	is_active = models.BooleanField()
	item = models.ForeignKey(Item, on_delete=models.CASCADE)


class User(models.Model):
	username = models.CharField(max_length=100)


class UserDeal(models.Model):
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	deal = models.ForeignKey(Deal, on_delete=models.CASCADE)
