from django import views
import json
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from deals.helpers.deal_helper import DealHelper


# Create your views here.

class DealView(views.View):
	@csrf_exempt
	def create_deal(request):
		try:
			deal_data = request.POST
			response = DealHelper.create_deal(deal_data)
			if response:
				return HttpResponse(json.dumps(response), content_type="application/json", status=200)
		except Exception as error:
			return HttpResponse(
				json.dumps({
					'success': False,
					'errors': [str(error)]
				}),
				content_type="application/json",
				status=400
			)

	@csrf_exempt
	def end_deal(self, request):
		try:
			response = DealHelper.end_deal(request.data['deal_id'])
			return HttpResponse(response, status=200)
		except Exception as e:
			return HttpResponse(
				{
					'success': False,
					'errors': [str(e)]
				},
				status=400
			)

	@csrf_exempt
	def update_deal(self, request):
		try:
			response = DealHelper.update_deal(request.data)
			return HttpResponse(response, status=200)
		except Exception as e:
			return HttpResponse(
				{
					'success': False,
					'errors': [str(e)]
				},
				status=400
			)

	@csrf_exempt
	def claim_deal(self, request):
		try:
			user_id, deal_id = request.data['user_id'], request.data['deal_id']
			response = DealHelper.claim_deal(deal_id, user_id)
			return HttpResponse(response, status=200)
		except Exception as e:
			return HttpResponse(
				{
					'success': False,
					'errors': [str(e)]
				},
				status=400
			)
